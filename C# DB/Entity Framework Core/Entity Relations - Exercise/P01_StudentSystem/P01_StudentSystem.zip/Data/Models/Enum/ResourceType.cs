﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Data.Models.Enum
{
    public enum ResourceType
    {
        Video, Presentation, Document, Other
    }
}
